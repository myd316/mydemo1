package com.offcn.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/SessionDemo1Servlet")
public class SessionDemo1Servlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();  // 获取session对象。如果没有就创建，如果有直接拿到
        System.out.println(session.getId());
        HttpSession session2 = request.getSession();
        System.out.println(session2.getId());


        HttpSession session3 = request.getSession(false);  // 获取session对象，如果有直接拿，如果没有返回null
        System.out.println(session3.getId());
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
           this.doPost(request, response);
    }
}
