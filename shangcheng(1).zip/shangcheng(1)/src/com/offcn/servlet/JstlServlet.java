package com.offcn.servlet;

import com.offcn.bean.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet("/JstlServlet")
public class JstlServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        User u = new User();
        u.setName("张三丰");
        u.setSex("男");
        u.setBirthday(new Date());
        u.setEmail("zhangsanfeng@xxx.com");
        u.setPassword("123");
        u.setUsername("zhangsanfeng");
        u.setId(100);

        User u2 = new User();
        u2.setName("李四丰");
        u2.setSex("女");
        u2.setBirthday(new Date());
        u2.setEmail("lisifeng@xxx.com");
        u2.setPassword("123");
        u2.setUsername("lisifeng");
        u2.setId(101);

        User u3 = new User();
        u3.setName("王五丰");
        u3.setSex("男");
        u3.setBirthday(new Date());
        u3.setEmail("wangwufeng@xxx.com");
        u3.setPassword("123");
        u3.setUsername("wangwufeng");
        u3.setId(102);

        List<User> list = new ArrayList<>();
        list.add(u);
        list.add(u2);
        list.add(u3);
        request.setAttribute("list",list);


        request.setAttribute("u",u);

        request.getRequestDispatcher("jstl.jsp").forward(request,response);


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          this.doPost(request,response);
    }
}
