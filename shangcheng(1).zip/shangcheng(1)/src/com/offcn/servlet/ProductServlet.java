package com.offcn.servlet;

import com.offcn.bean.Product;
import com.offcn.service.ProductService;
import com.offcn.service.impl.ProductServiceImpl;
import javafx.scene.effect.SepiaTone;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         //request.setCharacterEncoding("UTF-8");

         String method = request.getParameter("method");

         if("findAllProduct".equals(method)){
                findAllProduct(request,response);
         }else if("findProductById".equals(method)){
             findProductById(request,response);
         }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    protected void findAllProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        ProductService service = new ProductServiceImpl();

        List<Product> remenList = service.getProductByState(1);  // 热门商品
        List<Product> youxuanList = service.getProductByState(2);  // 优选商品

        // 把查询回的数据，存放到作用域中保存，跳转到展示页面进行展示

        // servlet中，有三个作用域 （request session  ServletContext）   jsp中，有四个作用域（page request session application）

        // 把两个list保存到request作用域中
        request.setAttribute("remen",remenList);
        request.setAttribute("youxuan",youxuanList);


        // 跳转到展示页面展示数据    重定向     请求转发（转发）
        //response.sendRedirect("jsp/showAllProducts.jsp");
        request.getRequestDispatcher("jsp/showAllProducts.jsp").forward(request,response);

    }

    protected void findProductById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String proId = request.getParameter("proid");

        ProductService service = new ProductServiceImpl();

        Product p = service.getProductById(Integer.parseInt(proId));
        request.setAttribute("p",p);
        request.getRequestDispatcher("jsp/product_info.jsp").forward(request,response);
    }

}


