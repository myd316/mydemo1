package com.offcn.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import com.offcn.bean.User;
import com.offcn.service.UserService;
import com.offcn.service.impl.UserServiceImpl;
import com.offcn.utils.DateUtil;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // 解决post请求乱码问题。 在获取数据之前！！！！
        //request.setCharacterEncoding("UTF-8");

        String method = request.getParameter("method");

        if("add".equals(method)){
              add(request,response);
        }else if("login".equals(method)){
              login(request,response);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
           this.doPost(request, response);
    }

    protected void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        // 在register.html上提交表单。 register.html发送一个post请求到UserServlet。执行UserServlet中的doPost方法！
        // 请求的全部信息都封装在了request这个对象中

        // 从request中获取表单提交的数据
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String sex = request.getParameter("sex");
        String name = request.getParameter("name");
        String birthday = request.getParameter("birthday");

/*        System.out.println("username:   "+username);
        System.out.println("password:   "+password);
        System.out.println("email:   "+email);
        System.out.println("sex:   "+sex);
        System.out.println("name:   "+name);
        System.out.println("birthday:   "+birthday);
  */
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setSex(sex);
        user.setName(name);
        user.setEmail(email);
        user.setBirthday(DateUtil.stringToDate(birthday));

        UserService service = new UserServiceImpl();
        int result = service.addUser(user);

        if(result>0){  // 添加成功后，跳转到登录页面

            response.sendRedirect("jsp/login.jsp");  // 重定向

        }else{
            response.sendRedirect("jsp/error.jsp");
        }
    }

    protected void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

             // 1 获取数据
             String username = request.getParameter("username");
             String password = request.getParameter("password");

             // 2调用后台代码
             UserService service = new UserServiceImpl();

             User user = service.login(username,password);

             // 3 控制跳转
             if(user!=null){  //登录成功
                 HttpSession session = request.getSession();
                 session.setAttribute("user",user);          // 登录成功后，登录人的信息存入session中

                 response.sendRedirect("jsp/index.jsp");
             }else{  // 登录失败
                 response.sendRedirect("jsp/login.jsp?message=loginerror");
             }


    }
}
