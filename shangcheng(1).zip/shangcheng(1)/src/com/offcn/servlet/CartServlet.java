package com.offcn.servlet;

import com.offcn.bean.Product;
import com.offcn.service.ProductService;
import com.offcn.service.impl.ProductServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         String method = request.getParameter("method");
         if("buy".equals(method)){
             buy(request,response);
         }else if("removeFromCart".equals(method)){
             removeFromCart(request,response);
         }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    // 购买商品加入购物车
    protected void buy(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /*
         * 总体思路：   购买的商品和数量加入到map（map作为购物车）中，map的key存购买的商品  value存购买数量
         *             map存入session中
         * */

        ProductService service = new ProductServiceImpl();

        String proid = request.getParameter("proid");
        // 要购买的商品
        Product p = service.getProductById(Integer.parseInt(proid));
        // 购买数量
        Integer num = Integer.parseInt(request.getParameter("num"));

        HttpSession session = request.getSession();

        // 从session中获取购物车
        Map<Product,Integer> cart = (Map<Product,Integer>)session.getAttribute("cart");

        if(cart==null){
            cart = new HashMap<>();
        }

         /*
         * 商品和数量加入购物车的思路：
         * 判断购物车中是否已有该商品，如果没有直接把商品和数量存入。如果已有该商品，只增加该商品的数量

             查找购物车中是否包含当前商品的思路：
               错误的做法： 根据当前的商品直接使用get方法到cart中获取。因为即使购买相同商品，不同次进入购买页面对象也是不同
               正确的做法是比较商品的id！！！

               先取出map中的所有key  是否有某个key的id和当前要购买的商品的id一致！
          */

        Set<Product> ps =  cart.keySet();
        boolean flag = false; // 假设不包含当前要购买的商品

        Product pp = null;
        for(Product pro:ps){
            if(pro.getPro_id()==p.getPro_id()){
                pp=pro;  // 找到商品，用一个引用把它保存起来，因为出了循环要使用这个商品的引用
                flag = true;
                break;
            }
        }
        if(flag){  // 说明已经选择过该商品
            Integer x = cart.get(pp);
            cart.put(pp,x+num);
        }else{  // 没选择过该商品
            cart.put(p,num);
        }

        // 把购物车存入session
        session.setAttribute("cart",cart);

        // 重定向到结算页面
        response.sendRedirect("jsp/cart.jsp");
    }

    // 从购物车中删除商品
    protected void removeFromCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        Map<Product,Integer> cart = (Map<Product,Integer>)session.getAttribute("cart");

        // map(p1,2) (p2,3) (p3,4)

        String proid = request.getParameter("proid");

        Set<Product> ps = cart.keySet();

        Product pp = null;
        for(Product pro:ps){
            if(pro.getPro_id()==Integer.parseInt(proid)){
                pp = pro;
                break;
            }
        }
        cart.remove(pp);
        response.sendRedirect("jsp/cart.jsp");
    }
}
