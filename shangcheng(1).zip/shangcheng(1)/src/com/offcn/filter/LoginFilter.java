package com.offcn.filter;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import com.offcn.bean.User;
@WebFilter(urlPatterns = {"/CartServlet","/PayServlet","/jsp/cart.jsp"})
public class LoginFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {

        // 通过判断session中是否有User的对象来表示登录或没登录

        HttpServletRequest request =  (HttpServletRequest)req;
        HttpServletResponse response = (HttpServletResponse)resp;
        HttpSession session  = request.getSession();

        User user = (User)session.getAttribute("user");

        if(user!=null){  // 已登录
            chain.doFilter(req, resp);
        }else{ // 未登录
            response.sendRedirect(request.getContextPath()+"/jsp/login.jsp?message=pleaselogin");
        }
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
