package com.offcn.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

//@WebFilter("/SessionDemo1Servlet")
public class Demo1Filter implements Filter {
    public void destroy() {
        System.out.println("Demo1Filter升天了");
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        System.out.println("Demo1Filter...doFilter方法...");

        chain.doFilter(req,resp);  // 放行

    }

    //Filter 在服务器启动时就创建了Filter的对象，并执行init方法一次
    public void init(FilterConfig config) throws ServletException {
        System.out.println("Demo1Filter出生了...");
    }

}
