package com.offcn.bean;

public class Product {

    private int pro_id;            // id
    private String pro_name;       // 商品名称
    private String pro_num;        // 商品编号
    private double market_price;   // 市场价
    private double shop_price;     // 商城价
    private String pro_color;      // 颜色
    private int pro_total_count;   // 数量
    private String pro_max_img;    // 大图片
    private String pro_min_img;    // 小图片
    private int pro_state;         //状态  （1 热门   2优选）

    public int getPro_id() {
        return pro_id;
    }

    public void setPro_id(int pro_id) {
        this.pro_id = pro_id;
    }

    public String getPro_name() {
        return pro_name;
    }

    public void setPro_name(String pro_name) {
        this.pro_name = pro_name;
    }

    public String getPro_num() {
        return pro_num;
    }

    public void setPro_num(String pro_num) {
        this.pro_num = pro_num;
    }

    public double getMarket_price() {
        return market_price;
    }

    public void setMarket_price(double market_price) {
        this.market_price = market_price;
    }

    public double getShop_price() {
        return shop_price;
    }

    public void setShop_price(double shop_price) {
        this.shop_price = shop_price;
    }

    public String getPro_color() {
        return pro_color;
    }

    public void setPro_color(String pro_color) {
        this.pro_color = pro_color;
    }

    public int getPro_total_count() {
        return pro_total_count;
    }

    public void setPro_total_count(int pro_total_count) {
        this.pro_total_count = pro_total_count;
    }

    public String getPro_max_img() {
        return pro_max_img;
    }

    public void setPro_max_img(String pro_max_img) {
        this.pro_max_img = pro_max_img;
    }

    public String getPro_min_img() {
        return pro_min_img;
    }

    public void setPro_min_img(String pro_min_img) {
        this.pro_min_img = pro_min_img;
    }

    public int getPro_state() {
        return pro_state;
    }

    public void setPro_state(int pro_state) {
        this.pro_state = pro_state;
    }
}
