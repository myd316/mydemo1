package com.offcn.dao.impl;

import com.offcn.bean.User;
import com.offcn.dao.UserDao;
import com.offcn.utils.DataSourceUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.SQLException;

public class UserDaoImpl implements UserDao {
    @Override
    public int insertUser(User user) {

        QueryRunner qr = new QueryRunner(DataSourceUtil.getDataSource());
        String sql = "insert into user values(null,?,?,?,?,?,?)";
        int result = 0;

        try {
            result = qr.update(sql,new Object[]{user.getUsername(),user.getPassword(),user.getEmail(),user.getName(),user.getSex(),user.getBirthday()});
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public User findUserByNameAndPassword(String username, String password) {

        User user = null;
        QueryRunner qr = new QueryRunner(DataSourceUtil.getDataSource());
        String sql = "select * from user where username=? and password=?";
        try {
            user = qr.query(sql,new BeanHandler<>(User.class),new Object[]{username,password});
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }
}