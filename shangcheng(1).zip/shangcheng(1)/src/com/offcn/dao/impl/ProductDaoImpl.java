package com.offcn.dao.impl;

import com.offcn.bean.Product;
import com.offcn.dao.ProductDao;
import com.offcn.utils.DataSourceUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

public class ProductDaoImpl implements ProductDao {
    @Override
    public List<Product> findProductByState(int state) {

        List<Product> list = null;

        QueryRunner qr = new QueryRunner(DataSourceUtil.getDataSource());
        String sql = "select * from product where pro_state=?";

        try {
            list = qr.query(sql,new BeanListHandler<>(Product.class),state);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Product findProductById(int id) {
        Product product = null;
        QueryRunner qr = new QueryRunner(DataSourceUtil.getDataSource());
        String sql = "select * from product where pro_id=?";

        try {
            product = qr.query(sql,new BeanHandler<>(Product.class),id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return product;
    }
}
