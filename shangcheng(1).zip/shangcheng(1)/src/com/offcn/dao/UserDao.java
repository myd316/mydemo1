package com.offcn.dao;
import com.offcn.bean.User;

public interface UserDao {

    public int insertUser(User user);

    public User findUserByNameAndPassword(String username,String password);

}
